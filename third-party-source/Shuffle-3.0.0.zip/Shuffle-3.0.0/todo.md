# Todos and other improvements

## Improvements
* More JSDoc
* Create an `Item` class for shuffle items so they can handle storing values and more.
